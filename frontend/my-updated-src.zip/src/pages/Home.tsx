import { Link } from "react-router-dom";
import { ArrowRight, Receipt, DollarSign, Activity, AlertTriangle, Pill, Star } from "lucide-react";
import { Button } from "@/components/ui/button";

const modules = [
  {
    icon: Receipt,
    title: "Claims Analytics",
    description: "Analyze prescription claims volume, trends, and processing metrics.",
  },
  {
    icon: DollarSign,
    title: "Cost Management",
    description: "Track and optimize pharmacy spend across all drug categories.",
  },
  {
    icon: Activity,
    title: "Utilization Insights",
    description: "Monitor drug utilization patterns and identify optimization opportunities.",
  },
  {
    icon: AlertTriangle,
    title: "Risk Detection",
    description: "Identify high-risk prescribing patterns and intervention opportunities.",
  },
  {
    icon: Pill,
    title: "Adherence Tracking",
    description: "Measure medication adherence rates and patient compliance.",
  },
  {
    icon: Star,
    title: "Specialty Drugs",
    description: "Manage specialty pharmacy costs and utilization analytics.",
  },
];

const Home = () => {
  return (
    <div className="animate-fade-in">
      {/* Hero Section */}
      <div className="text-center mb-12">
        <h1 className="text-4xl md:text-5xl font-bold gradient-title mb-4">
          PharmEngine AI
        </h1>
        <p className="text-xl font-medium text-foreground mb-2">
          Enterprise Pharmacy Analytics Platform
        </p>
        <p className="text-muted-foreground max-w-2xl mx-auto mb-8">
          Transform your pharmacy data into actionable insights with AI-powered analytics, 
          cost optimization, and predictive forecasting.
        </p>
        <Link to="/analysis">
          <Button className="bg-primary hover:bg-primary/90 text-primary-foreground px-6 py-3 rounded-full text-base font-medium shadow-lg shadow-primary/25 transition-all duration-200 hover:shadow-xl hover:shadow-primary/30">
            View Analytics
            <ArrowRight className="w-4 h-4 ml-2" />
          </Button>
        </Link>
      </div>

      {/* Feature Tiles Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {modules.map((module, index) => {
          const Icon = module.icon;
          return (
            <div
              key={index}
              className="feature-card text-center group"
            >
              <div className="w-12 h-12 mx-auto mb-4 rounded-xl bg-primary/10 flex items-center justify-center group-hover:bg-primary/20 transition-colors duration-200">
                <Icon className="w-6 h-6 text-primary" />
              </div>
              <h3 className="text-lg font-semibold text-foreground mb-2">
                {module.title}
              </h3>
              <p className="text-sm text-muted-foreground leading-relaxed">
                {module.description}
              </p>
            </div>
          );
        })}
      </div>
    </div>
  );
};

export default Home;
