import { useState } from "react";
import { Link } from "react-router-dom";
import { ArrowLeft, Send, Receipt, DollarSign, Activity, AlertTriangle, Pill, Bot } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";

const quickActions = [
  { icon: Receipt, label: "Claims Summary" },
  { icon: DollarSign, label: "Cost Analysis" },
  { icon: Activity, label: "Utilization Report" },
  { icon: AlertTriangle, label: "Risk Alerts" },
  { icon: Pill, label: "Drug Trends" },
];

interface Message {
  role: "assistant" | "user";
  content: string;
}

const Chat = () => {
  const [messages, setMessages] = useState<Message[]>([
    {
      role: "assistant",
      content: "Hi there, I'm your PharmEngine AI assistant. I've analyzed your pharmacy data and I'm here to help. What would you like to know about your claims, costs, or utilization today?",
    },
  ]);
  const [input, setInput] = useState("");

  const handleSend = async () => {
    if (!input.trim()) return;
    
    const userMessage: Message = { role: "user", content: input };
    setMessages((prev) => [...prev, userMessage]);
    const question = input;
    setInput("");

    try {
      const response = await fetch('http://localhost:8000/api/query', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ question })
      });
      
      const data = await response.json();
      
      const aiMessage: Message = {
        role: "assistant",
        content: data.response
      };
      setMessages((prev) => [...prev, aiMessage]);
    } catch (error) {
      const errorMessage: Message = {
        role: "assistant",
        content: "Error: Unable to connect to backend. Make sure the API is running on port 8000."
      };
      setMessages((prev) => [...prev, errorMessage]);
    }
  };

  const handleQuickAction = (label: string) => {
    setInput(`Tell me about ${label.toLowerCase()}`);
  };

  return (
    <div className="animate-fade-in h-[calc(100vh-180px)] flex flex-col">
      <Link 
        to="/analysis" 
        className="inline-flex items-center gap-2 text-primary hover:text-primary/80 transition-colors mb-4"
      >
        <ArrowLeft className="w-4 h-4" />
        Back to Analysis
      </Link>

      <div className="text-center mb-6">
        <h1 className="text-2xl font-bold gradient-title mb-2">
          PharmEngine AI Assistant
        </h1>
        <p className="text-sm text-muted-foreground">
          Chat with me about your pharmacy analytics. I'm here to help you understand 
          your data and find actionable insights.
        </p>
      </div>

      <div className="flex flex-wrap justify-center gap-2 mb-6">
        {quickActions.map((action, index) => {
          const Icon = action.icon;
          return (
            <button
              key={index}
              onClick={() => handleQuickAction(action.label)}
              className="quick-action-pill"
            >
              <Icon className="w-4 h-4 text-primary" />
              {action.label}
            </button>
          );
        })}
      </div>

      <div className="flex-1 bg-card rounded-xl border border-border overflow-hidden flex flex-col">
        <div className="flex-1 overflow-y-auto p-4 space-y-4">
          {messages.map((message, index) => (
            <div
              key={index}
              className={`flex gap-3 ${
                message.role === "user" ? "flex-row-reverse" : ""
              }`}
            >
              {message.role === "assistant" && (
                <div className="w-8 h-8 rounded-lg bg-primary/10 flex items-center justify-center flex-shrink-0">
                  <Bot className="w-4 h-4 text-primary" />
                </div>
              )}
              <div
                className={`max-w-[80%] p-4 rounded-xl ${
                  message.role === "assistant"
                    ? "bg-muted text-foreground"
                    : "bg-primary text-primary-foreground ml-auto"
                }`}
              >
                {message.content}
              </div>
            </div>
          ))}
        </div>

        <div className="p-4 border-t border-border">
          <div className="flex gap-2">
            <Input
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyDown={(e) => e.key === "Enter" && handleSend()}
              placeholder="Ask about your pharmacy analytics..."
              className="flex-1 bg-background border-border focus-visible:ring-primary"
            />
            <Button
              onClick={handleSend}
              className="bg-primary hover:bg-primary/90 text-primary-foreground rounded-full w-10 h-10 p-0"
            >
              <Send className="w-4 h-4" />
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Chat;