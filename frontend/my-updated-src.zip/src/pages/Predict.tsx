import { useState, useEffect } from "react";
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, CartesianGrid } from "recharts";

interface ChartData {
  period: string;
  value: number;
}

const Predict = () => {
  const [costTrend, setCostTrend] = useState<ChartData[]>([]);
  const [categoryData, setCategoryData] = useState<ChartData[]>([]);
  const [tierData, setTierData] = useState<ChartData[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadPredictionData();
  }, []);

  const loadPredictionData = async () => {
    try {
      const costSql = `
        SELECT 
          FORMAT_TIMESTAMP('%b %Y', DATE_TRUNC(fill_date, MONTH)) as period,
          ROUND(SUM(drug_cost)/1000, 1) as value
        FROM \`pharmengine-ai.pharmacy_analytics.prescription_claims\`
        WHERE fill_date >= TIMESTAMP_SUB(CURRENT_TIMESTAMP(), INTERVAL 6 MONTH)
        GROUP BY period
        ORDER BY MIN(fill_date)
      `;

      const costRes = await fetch('http://localhost:8000/api/sql', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ sql: costSql })
      });
      
      const costData = await costRes.json();
      const costLines = costData.result.split('\n').slice(2).filter((line: string) => line.trim() && !line.includes('Query returned'));
      const costParsed = costLines.map((line: string) => {
        const parts = line.trim().split(/\s+/);
        return {
          period: parts.slice(0, 2).join(' '),
          value: parseFloat(parts[2])
        };
      }).filter((item: any) => !isNaN(item.value));

      setCostTrend(costParsed);
      console.log('Cost trend data:', costParsed);

      const categorySql = `
        SELECT 
          drug_category,
          ROUND(SUM(drug_cost)/1000, 1) as value
        FROM \`pharmengine-ai.pharmacy_analytics.prescription_claims\`
        WHERE fill_date >= TIMESTAMP_SUB(CURRENT_TIMESTAMP(), INTERVAL 90 DAY)
        GROUP BY drug_category
        ORDER BY value DESC
      `;

      const catRes = await fetch('http://localhost:8000/api/sql', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ sql: categorySql })
      });

      const catData = await catRes.json();
      const catLines = catData.result.split('\n').slice(2).filter((line: string) => line.trim() && !line.includes('Query returned'));
      const catParsed = catLines.map((line: string) => {
        const parts = line.trim().split(/\s+/);
        return {
          period: parts[0],
          value: parseFloat(parts[1])
        };
      }).filter((item: any) => !isNaN(item.value));

      setCategoryData(catParsed);

      const tierSql = `
        SELECT 
          CONCAT('Tier ', CAST(tier AS STRING)) as period,
          ROUND(SUM(drug_cost)/1000, 1) as value
        FROM \`pharmengine-ai.pharmacy_analytics.prescription_claims\`
        WHERE fill_date >= TIMESTAMP_SUB(CURRENT_TIMESTAMP(), INTERVAL 90 DAY)
        GROUP BY tier
        ORDER BY tier
      `;

      const tierRes = await fetch('http://localhost:8000/api/sql', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ sql: tierSql })
      });

      const tierData = await tierRes.json();
      const tierLines = tierData.result.split('\n').slice(2).filter((line: string) => line.trim() && !line.includes('Query returned'));
      const tierParsed = tierLines.map((line: string) => {
        const parts = line.trim().split(/\s+/);
        return {
          period: parts.slice(0, 2).join(' '),
          value: parseFloat(parts[2])
        };
      }).filter((item: any) => !isNaN(item.value));

      setTierData(tierParsed);
      setLoading(false);

    } catch (error) {
      console.error('Failed to load prediction data:', error);
      setLoading(false);
    }
  };

  return (
    <div className="animate-fade-in">
      <div className="text-center mb-10">
        <h1 className="text-3xl font-bold gradient-title mb-3">Analytics & Trends</h1>
        <p className="text-muted-foreground max-w-2xl mx-auto">
          Real-time trend analysis from your pharmacy claims data
        </p>
      </div>

      <div className="grid grid-cols-3 gap-6">
        {/* Chart 1 */}
        <div className="chart-card">
          <h3 className="text-lg font-semibold text-foreground mb-4">Monthly Cost Trend</h3>
          
          {loading ? (
            <div className="flex items-center justify-center h-[280px] text-muted-foreground">Loading...</div>
          ) : (
            <ResponsiveContainer width="100%" height={280}>
              <BarChart data={costTrend}>
                <CartesianGrid strokeDasharray="3 3" stroke="hsl(240, 5%, 20%)" />
                <XAxis dataKey="period" tick={{ fill: "hsl(240, 5%, 46%)", fontSize: 10 }} angle={-45} textAnchor="end" height={70} />
                <YAxis tick={{ fill: "hsl(240, 5%, 46%)", fontSize: 10 }} />
                <Tooltip contentStyle={{ backgroundColor: "hsl(0, 0%, 10%)", border: "1px solid hsl(240, 5%, 20%)", borderRadius: "8px", color: "#FFF" }} />
                <Bar dataKey="value" fill="#3B82F6" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          )}
        </div>

        {/* Chart 2 */}
        <div className="chart-card">
          <h3 className="text-lg font-semibold text-foreground mb-4">Cost by Category</h3>
          
          {loading ? (
            <div className="flex items-center justify-center h-[280px] text-muted-foreground">Loading...</div>
          ) : (
            <ResponsiveContainer width="100%" height={280}>
              <BarChart data={categoryData}>
                <CartesianGrid strokeDasharray="3 3" stroke="hsl(240, 5%, 20%)" />
                <XAxis dataKey="period" tick={{ fill: "hsl(240, 5%, 46%)", fontSize: 10 }} angle={-45} textAnchor="end" height={70} />
                <YAxis tick={{ fill: "hsl(240, 5%, 46%)", fontSize: 10 }} />
                <Tooltip contentStyle={{ backgroundColor: "hsl(0, 0%, 10%)", border: "1px solid hsl(240, 5%, 20%)", borderRadius: "8px", color: "#FFF" }} />
                <Bar dataKey="value" fill="#EF4444" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          )}
        </div>

        {/* Chart 3 */}
        <div className="chart-card">
          <h3 className="text-lg font-semibold text-foreground mb-4">Cost by Tier</h3>
          
          {loading ? (
            <div className="flex items-center justify-center h-[280px] text-muted-foreground">Loading...</div>
          ) : (
            <ResponsiveContainer width="100%" height={280}>
              <BarChart data={tierData}>
                <CartesianGrid strokeDasharray="3 3" stroke="hsl(240, 5%, 20%)" />
                <XAxis dataKey="period" tick={{ fill: "hsl(240, 5%, 46%)", fontSize: 10 }} />
                <YAxis tick={{ fill: "hsl(240, 5%, 46%)", fontSize: 10 }} />
                <Tooltip contentStyle={{ backgroundColor: "hsl(0, 0%, 10%)", border: "1px solid hsl(240, 5%, 20%)", borderRadius: "8px", color: "#FFF" }} />
                <Bar dataKey="value" fill="#8B5CF6" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          )}
        </div>
      </div>
    </div>
  );
};

export default Predict;