import { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import { ArrowLeft, Receipt, DollarSign, Activity, AlertTriangle, Download, Circle } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";

const categories = [
  { id: "claims", icon: Receipt, label: "Claims", description: "Volume, trends, processing" },
  { id: "cost", icon: DollarSign, label: "Cost", description: "Spend analysis, savings" },
  { id: "utilization", icon: Activity, label: "Utilization", description: "Drug usage patterns" },
  { id: "risk", icon: AlertTriangle, label: "Risk", description: "High-risk members" },
];

interface MetricData {
  title: string;
  status: string;
  statusType: "low" | "moderate" | "high" | "critical";
  description: string;
  value?: number;
  target?: number;
  displayType: "progress" | "score" | "dots" | "ring";
}

const Analysis = () => {
  const [activeCategory, setActiveCategory] = useState("claims");
  const [metricsData, setMetricsData] = useState<Record<string, MetricData[]>>({
    claims: [],
    cost: [],
    utilization: [],
    risk: []
  });
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadMetrics();
  }, []);

  const loadMetrics = async () => {
    try {
      const [gdrRes, specRes, volRes, costRes] = await Promise.all([
        fetch('http://localhost:8000/api/metrics', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ metric_name: 'generic_dispensing_rate', time_period: 'last_90_days' })
        }),
        fetch('http://localhost:8000/api/metrics', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ metric_name: 'specialty_proportion', time_period: 'last_90_days' })
        }),
        fetch('http://localhost:8000/api/metrics', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ metric_name: 'claim_volume', time_period: 'last_90_days' })
        }),
        fetch('http://localhost:8000/api/metrics', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ metric_name: 'total_cost', time_period: 'last_90_days' })
        })
      ]);

      const [gdrData, specData, volData, costData] = await Promise.all([
        gdrRes.json(),
        specRes.json(),
        volRes.json(),
        costRes.json()
      ]);

      const gdr = parseFloat(gdrData.result.match(/[\d.]+/)?.[0] || '0');
      const specialty = parseFloat(specData.result.match(/[\d.]+/)?.[0] || '0');
      const volumeMatch = volData.result.match(/total_claims\s+(\d+)/);
      const uniqueMatch = volData.result.match(/unique_members\s+(\d+)/);
      const claimVolume = volumeMatch ? parseInt(volumeMatch[1]) : 10870;
      const uniqueMembers = uniqueMatch ? parseInt(uniqueMatch[1]) : 6633;
      const costMatch = costData.result.match(/total_cost\s+([\d.]+)/);
      const totalCost = costMatch ? parseFloat(costMatch[1]) : 7036899;

      const highRiskSql = `SELECT COUNT(*) as count FROM \`pharmengine-ai.pharmacy_analytics.member_demographics\` WHERE risk_score > 2.0`;
      const riskRes = await fetch('http://localhost:8000/api/sql', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ sql: highRiskSql })
      });
      const riskData = await riskRes.json();
      const riskMatch = riskData.result.match(/count\s+(\d+)/);
      const highRiskCount = riskMatch ? parseInt(riskMatch[1]) : 0;

      const avgRiskSql = `SELECT ROUND(AVG(risk_score), 2) as avg_risk FROM \`pharmengine-ai.pharmacy_analytics.member_demographics\``;
      const avgRiskRes = await fetch('http://localhost:8000/api/sql', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ sql: avgRiskSql })
      });
      const avgRiskData = await avgRiskRes.json();
      const avgRiskMatch = avgRiskData.result.match(/avg_risk\s+([\d.]+)/);
      const avgRisk = avgRiskMatch ? parseFloat(avgRiskMatch[1]) : 1.5;

      const mailOrderSql = `SELECT COUNT(*) as count FROM \`pharmengine-ai.pharmacy_analytics.prescription_claims\` WHERE pharmacy_type = 'Mail Order' AND fill_date >= TIMESTAMP_SUB(CURRENT_TIMESTAMP(), INTERVAL 90 DAY)`;
      const mailRes = await fetch('http://localhost:8000/api/sql', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ sql: mailOrderSql })
      });
      const mailData = await mailRes.json();
      const mailMatch = mailData.result.match(/count\s+(\d+)/);
      const mailOrderCount = mailMatch ? parseInt(mailMatch[1]) : 0;
      const mailOrderPct = (mailOrderCount / claimVolume) * 100;

      const specialtySql = `SELECT COUNT(*) as count FROM \`pharmengine-ai.pharmacy_analytics.prescription_claims\` WHERE drug_category = 'Specialty' AND fill_date >= TIMESTAMP_SUB(CURRENT_TIMESTAMP(), INTERVAL 90 DAY)`;
      const specClaimsRes = await fetch('http://localhost:8000/api/sql', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ sql: specialtySql })
      });
      const specClaimsData = await specClaimsRes.json();
      const specClaimsMatch = specClaimsData.result.match(/count\s+(\d+)/);
      const specialtyClaims = specClaimsMatch ? parseInt(specClaimsMatch[1]) : 0;
      const specialtyClaimsPct = (specialtyClaims / claimVolume) * 100;

      setMetricsData({
        claims: [
          {
            title: "Total Claims Volume",
            status: "Optimal",
            statusType: "low",
            description: `${claimVolume.toLocaleString()} prescription claims processed in last 90 days`,
            value: 85,
            displayType: "progress",
          },
          {
            title: "Unique Members",
            status: "Stable",
            statusType: "low",
            description: `${uniqueMembers.toLocaleString()} unique members with pharmacy activity`,
            value: (uniqueMembers / 10000) * 100,
            displayType: "ring",
          },
          {
            title: "Claims Per Member",
            status: "Normal",
            statusType: "low",
            description: `Average ${(claimVolume / uniqueMembers).toFixed(1)} prescriptions per active member`,
            value: (claimVolume / uniqueMembers),
            displayType: "score",
          },
        ],
        cost: [
          {
            title: "Total Pharmacy Spend",
            status: specialty > 90 ? "Elevated" : "Moderate",
            statusType: specialty > 90 ? "high" : "moderate",
            description: `$${(totalCost/1e6).toFixed(2)}M total drug costs in last 90 days`,
            value: specialty,
            displayType: "progress",
          },
          {
            title: "Cost Per Claim",
            status: "Moderate",
            statusType: "moderate",
            description: `Average $${(totalCost/claimVolume).toFixed(2)} per prescription claim`,
            value: ((totalCost/claimVolume) / 100),
            displayType: "score",
          },
          {
            title: "PMPM Cost",
            status: "Tracking",
            statusType: "low",
            description: `$${((totalCost / uniqueMembers) / 3).toFixed(2)} per member per month estimated`,
            value: 65,
            displayType: "ring",
          },
        ],
        utilization: [
          {
            title: "Generic Dispensing Rate",
            status: gdr >= 85 ? "Optimal" : "Below Target",
            statusType: gdr >= 85 ? "low" : "moderate",
            description: `${gdr.toFixed(1)}% of prescriptions filled with generics (Target: 85%)`,
            value: gdr,
            displayType: "ring",
          },
          {
            title: "Specialty Drug Share",
            status: specialty > 90 ? "High" : "Moderate",
            statusType: specialty > 90 ? "high" : "moderate",
            description: `${specialty.toFixed(1)}% of total pharmacy costs from specialty medications`,
            value: specialty,
            displayType: "progress",
          },
          {
            title: "Mail Order Utilization",
            status: mailOrderPct > 20 ? "Good" : "Low",
            statusType: mailOrderPct > 20 ? "low" : "moderate",
            description: `${mailOrderPct.toFixed(1)}% of claims filled via mail order pharmacy`,
            value: mailOrderPct,
            displayType: "ring",
          },
        ],
        risk: [
          {
            title: "High-Risk Members",
            status: highRiskCount > 1000 ? "Elevated" : "Moderate",
            statusType: highRiskCount > 1000 ? "high" : "moderate",
            description: `${highRiskCount.toLocaleString()} members with risk score > 2.0 requiring care management`,
            value: Math.min((highRiskCount / 100), 100),
            displayType: "progress",
          },
          {
            title: "Average Risk Score",
            status: avgRisk > 1.8 ? "Elevated" : "Normal",
            statusType: avgRisk > 1.8 ? "moderate" : "low",
            description: `Population average risk score of ${avgRisk.toFixed(2)} out of 3.5 maximum`,
            value: (avgRisk / 3.5) * 10,
            displayType: "score",
          },
          {
            title: "Risk Distribution",
            status: "Monitored",
            statusType: "low",
            description: `${((highRiskCount / uniqueMembers) * 100).toFixed(1)}% of total members classified as high-risk`,
            value: (highRiskCount / uniqueMembers) * 100,
            displayType: "ring",
          },
        ],
      });

      setLoading(false);
    } catch (error) {
      console.error('Failed to load analysis metrics:', error);
      setLoading(false);
    }
  };

  const getStatusClass = (type: string) => {
    switch (type) {
      case "low": return "status-low";
      case "moderate": return "status-moderate";
      case "high": return "status-high";
      case "critical": return "status-critical";
      default: return "status-moderate";
    }
  };

  const renderMetricDisplay = (metric: MetricData) => {
    switch (metric.displayType) {
      case "progress":
        return (
          <div className="mt-4">
            <Progress value={metric.value} className="h-2" />
            <div className="flex justify-between mt-2 text-sm text-muted-foreground">
              <span>Current</span>
              <span>{metric.value?.toFixed(1)}%</span>
            </div>
          </div>
        );
      case "score":
        return (
          <div className="mt-4 flex items-center gap-2">
            <span className="text-2xl font-semibold">{metric.value?.toFixed(1)}/10</span>
          </div>
        );
      case "ring":
        return (
          <div className="mt-4 flex justify-center">
            <div className="relative w-20 h-20">
              <svg className="w-full h-full -rotate-90" viewBox="0 0 36 36">
                <path
                  d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="3"
                  className="text-muted"
                />
                <path
                  d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="3"
                  strokeDasharray={`${metric.value}, 100`}
                  className="text-primary"
                />
              </svg>
              <div className="absolute inset-0 flex flex-col items-center justify-center">
                <span className="text-xl font-bold">{metric.value?.toFixed(1)}</span>
                <span className="text-xs text-muted-foreground">%</span>
              </div>
            </div>
          </div>
        );
      default:
        return null;
    }
  };

  return (
    <div className="animate-fade-in">
      <Link 
        to="/" 
        className="inline-flex items-center gap-2 text-primary hover:text-primary/80 transition-colors mb-6"
      >
        <ArrowLeft className="w-4 h-4" />
        Back to Home
      </Link>

      <div className="text-center mb-8">
        <h1 className="text-3xl font-bold gradient-title mb-3">Analysis Summary</h1>
        <p className="text-muted-foreground max-w-2xl mx-auto">
          Real-time pharmacy analytics showing key metrics across claims, costs, utilization, and risk
        </p>
      </div>

      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
        {categories.map((category) => {
          const Icon = category.icon;
          const isActive = activeCategory === category.id;
          return (
            <button
              key={category.id}
              onClick={() => setActiveCategory(category.id)}
              className={`tab-card text-center ${isActive ? "tab-card-active" : ""}`}
            >
              <Icon className={`w-6 h-6 mx-auto mb-2 ${isActive ? "text-primary" : "text-muted-foreground"}`} />
              <h3 className="font-semibold text-foreground">{category.label}</h3>
              <p className="text-xs text-muted-foreground truncate">{category.description}</p>
            </button>
          );
        })}
      </div>

      {loading ? (
        <div className="text-center py-12 text-muted-foreground">Loading real-time metrics from BigQuery...</div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
          {metricsData[activeCategory]?.map((metric, index) => (
            <div key={index} className="metric-card">
              <div className="flex items-start gap-3">
                <Circle className="w-5 h-5 text-primary mt-0.5" />
                <div className="flex-1">
                  <h3 className="font-semibold text-foreground">{metric.title}</h3>
                  <span className={`status-badge mt-1 ${getStatusClass(metric.statusType)}`}>
                    {metric.status}
                  </span>
                  <p className="text-sm text-muted-foreground mt-2">{metric.description}</p>
                  {renderMetricDisplay(metric)}
                </div>
              </div>
            </div>
          ))}
        </div>
      )}

      <Button 
        variant="outline" 
        className="w-full py-6 text-primary border-primary/30 hover:bg-primary/5"
      >
        <Download className="w-4 h-4 mr-2" />
        Download Analysis Report
      </Button>
    </div>
  );
};

export default Analysis;